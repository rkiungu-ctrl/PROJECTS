import React from 'react'

const App = () => {
  return (
    <div className="min-h-screen bg-red-500 flex items-center justify-center text-white text-2xl font-bold">
      Tailwind is working 🎉
    </div>
  )
}

export default App
